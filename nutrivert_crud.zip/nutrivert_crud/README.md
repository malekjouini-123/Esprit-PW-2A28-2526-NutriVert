# NutriVert CRUD MVC

Projet PHP MVC / OOP / PDO avec CRUD complet pour les entités `recette` et `instruction`.

## Structure

- `config/` : configuration PDO
- `app/models/` : modèles OOP
- `app/controllers/` : contrôleurs
- `app/views/front/` : FrontOffice
- `app/views/back/` : BackOffice
- `public/` : point d'entrée + assets

## Installation

1. Importer `database/nutrivert.sql` dans phpMyAdmin.
2. Copier le projet dans `htdocs` (XAMPP) ou `www`.
3. Ajuster `config/config.php` si nécessaire.
4. Ouvrir `http://localhost/nutrivert_crud/public/index.php`.

## Contraintes respectées

- MVC
- Programmation orientée objet
- PDO obligatoire
- Contrôle de saisie sans validation HTML5 (`required`, `min`, etc. non utilisés)
