<?php

require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../app/models/Recette.php';
require_once __DIR__ . '/../app/models/Instruction.php';
require_once __DIR__ . '/../app/controllers/BaseController.php';
require_once __DIR__ . '/../app/controllers/HomeController.php';
require_once __DIR__ . '/../app/controllers/RecetteController.php';
require_once __DIR__ . '/../app/controllers/InstructionController.php';

$pdo = Database::getConnection();
$page = $_GET['page'] ?? 'front_home';
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

$homeController = new HomeController($pdo);
$recetteController = new RecetteController($pdo);
$instructionController = new InstructionController($pdo);

switch ($page) {
    case 'front_home':
        $homeController->index();
        break;

    case 'front_recette':
        $homeController->recetteDetail($id);
        break;

    case 'back_dashboard':
        $layout = 'back';
        $pageTitle = 'BackOffice | Dashboard';
        require __DIR__ . '/../app/views/back/dashboard.php';
        break;

    case 'back_recettes':
        $recetteController->index();
        break;

    case 'back_recette_create':
        $recetteController->create();
        break;

    case 'back_recette_store':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $recetteController->store();
            break;
        }
        header('Location: index.php?page=back_recettes');
        break;

    case 'back_recette_edit':
        $recetteController->edit($id);
        break;

    case 'back_recette_update':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $recetteController->update($id);
            break;
        }
        header('Location: index.php?page=back_recettes');
        break;

    case 'back_recette_delete':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $recetteController->delete($id);
            break;
        }
        header('Location: index.php?page=back_recettes');
        break;

    case 'back_instructions':
        $instructionController->index();
        break;

    case 'back_instruction_create':
        $instructionController->create();
        break;

    case 'back_instruction_store':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $instructionController->store();
            break;
        }
        header('Location: index.php?page=back_instructions');
        break;

    case 'back_instruction_edit':
        $instructionController->edit($id);
        break;

    case 'back_instruction_update':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $instructionController->update($id);
            break;
        }
        header('Location: index.php?page=back_instructions');
        break;

    case 'back_instruction_delete':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $instructionController->delete($id);
            break;
        }
        header('Location: index.php?page=back_instructions');
        break;

    default:
        http_response_code(404);
        echo 'Page introuvable.';
}
