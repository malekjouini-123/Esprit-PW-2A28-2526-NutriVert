function confirmDelete() {
    return window.confirm('Confirmer la suppression ?');
}

document.addEventListener('DOMContentLoaded', function () {
    const forms = document.querySelectorAll('form[data-form]');

    forms.forEach(function (form) {
        form.addEventListener('submit', function (event) {
            const type = form.getAttribute('data-form');
            let errors = [];

            if (type === 'recette') {
                const titre = document.getElementById('titre').value.trim();
                const objectif = document.getElementById('objectif').value.trim();
                const regime = document.getElementById('regime').value.trim();
                const duree = document.getElementById('duree').value.trim();

                if (titre.length < 3) {
                    errors.push('Titre: minimum 3 caractères');
                }
                if (objectif.length < 5) {
                    errors.push('Objectif: minimum 5 caractères');
                }
                if (regime === '') {
                    errors.push('Régime obligatoire');
                }
                if (!/^\d+$/.test(duree) || parseInt(duree, 10) <= 0) {
                    errors.push('Durée invalide');
                }
            }

            if (type === 'instruction') {
                const idRecette = document.getElementById('id_recette').value.trim();
                const etape = document.getElementById('etape').value.trim();
                const description = document.getElementById('description').value.trim();
                const ingredientProduit = document.getElementById('ingredient_produit').value.trim();

                if (idRecette === '') {
                    errors.push('Choisir une recette');
                }
                if (etape.length < 2) {
                    errors.push('Étape: minimum 2 caractères');
                }
                if (description.length < 5) {
                    errors.push('Description: minimum 5 caractères');
                }
                if (ingredientProduit === '') {
                    errors.push('Ingrédients obligatoires');
                } else {
                    try {
                        JSON.parse(ingredientProduit);
                    } catch (e) {
                        errors.push('Le JSON des ingrédients est invalide');
                    }
                }
            }

            if (errors.length > 0) {
                event.preventDefault();
                alert(errors.join('\n'));
            }
        });
    });
});
