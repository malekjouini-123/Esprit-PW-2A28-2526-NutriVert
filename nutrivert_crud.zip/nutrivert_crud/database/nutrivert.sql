CREATE DATABASE IF NOT EXISTS nutrivert CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE nutrivert;

DROP TABLE IF EXISTS instruction;
DROP TABLE IF EXISTS recette;
DROP TABLE IF EXISTS produit;

CREATE TABLE produit (
  id_produit INT AUTO_INCREMENT PRIMARY KEY,
  nom_produit VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE recette (
  id_recette INT AUTO_INCREMENT PRIMARY KEY,
  titre VARCHAR(50) NOT NULL,
  objectif VARCHAR(100) NOT NULL,
  regime VARCHAR(50) NOT NULL,
  duree INT NOT NULL
);

CREATE TABLE instruction (
  id_instruction INT AUTO_INCREMENT PRIMARY KEY,
  id_recette INT NOT NULL,
  etape TEXT NOT NULL,
  description TEXT NOT NULL,
  ingredient_produit LONGTEXT NOT NULL,
  CONSTRAINT fk_instruction_recette FOREIGN KEY (id_recette)
    REFERENCES recette(id_recette)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT chk_ingredient_json CHECK (json_valid(ingredient_produit))
);

INSERT INTO produit (nom_produit) VALUES
('oeuf'), ('sucre'), ('farine'), ('lait'), ('huile');

INSERT INTO recette (titre, objectif, regime, duree) VALUES
('Gâteau simple', 'Dessert facile à préparer', 'Végétarien', 45),
('Salade verte', 'Repas léger et sain', 'Vegan', 15);

INSERT INTO instruction (id_recette, etape, description, ingredient_produit) VALUES
(1, 'Préparation de la pâte', 'Mélanger le sucre, la farine et les oeufs dans un bol.', '[{"id_produit":2,"nom_produit":"sucre","quantite":"100g"},{"id_produit":3,"nom_produit":"farine","quantite":"200g"},{"id_produit":1,"nom_produit":"oeuf","quantite":"2"}]'),
(2, 'Assemblage', 'Laver les légumes puis mélanger tous les ingrédients.', '[{"id_produit":5,"nom_produit":"huile","quantite":"2 cuillères"}]');
