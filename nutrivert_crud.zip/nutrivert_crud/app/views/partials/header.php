<?php
$isBackOffice = ($layout ?? 'front') === 'back';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle ?? 'NutriVert'); ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="<?php echo $isBackOffice ? 'back-layout' : 'front-layout'; ?>">
<header class="site-header <?php echo $isBackOffice ? 'back-header' : 'front-header'; ?>">
    <div class="brand-block">
        <div class="brand-logo">🌿</div>
        <div>
            <h1 class="brand-title">NutriVert</h1>
            <p class="brand-tagline">Mangez intelligemment, vivez durablement</p>
        </div>
    </div>

    <nav class="site-nav">
        <a href="index.php">FrontOffice</a>
        <a href="index.php?page=back_dashboard">BackOffice</a>
        <a href="index.php?page=back_recettes">Recettes</a>
        <a href="index.php?page=back_instructions">Instructions</a>
    </nav>
</header>
<main class="page-container">
