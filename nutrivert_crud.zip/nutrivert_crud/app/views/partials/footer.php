</main>
<footer class="site-footer">
    <p>© 2026 NutriVert - Projet CRUD MVC / OOP / PDO</p>
</footer>
<script src="assets/js/app.js"></script>
</body>
</html>
