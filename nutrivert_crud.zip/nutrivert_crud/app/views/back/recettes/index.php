<?php $layout = 'back'; require __DIR__ . '/../../partials/header.php'; ?>

<section class="toolbar">
    <div>
        <h2>CRUD Recettes</h2>
        <p class="muted">BackOffice de gestion des recettes.</p>
    </div>
    <a class="btn btn-primary" href="index.php?page=back_recette_create">Ajouter une recette</a>
</section>

<?php if (!empty($success)) { ?>
    <div class="alert success"><?php echo htmlspecialchars($success); ?></div>
<?php } ?>

<section class="table-card">
    <table class="data-table">
        <thead>
        <tr>
            <th>ID</th>
            <th>Titre</th>
            <th>Objectif</th>
            <th>Régime</th>
            <th>Durée</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php if (empty($recettes)) { ?>
            <tr><td colspan="6">Aucune recette trouvée.</td></tr>
        <?php } else { ?>
            <?php foreach ($recettes as $recette) { ?>
                <tr>
                    <td><?php echo (int) $recette['id_recette']; ?></td>
                    <td><?php echo htmlspecialchars($recette['titre']); ?></td>
                    <td><?php echo htmlspecialchars($recette['objectif']); ?></td>
                    <td><?php echo htmlspecialchars($recette['regime']); ?></td>
                    <td><?php echo (int) $recette['duree']; ?> min</td>
                    <td class="actions-cell">
                        <a class="btn btn-small" href="index.php?page=back_recette_edit&id=<?php echo (int) $recette['id_recette']; ?>">Modifier</a>
                        <form method="POST" action="index.php?page=back_recette_delete&id=<?php echo (int) $recette['id_recette']; ?>" onsubmit="return confirmDelete();">
                            <button class="btn btn-danger btn-small" type="submit">Supprimer</button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        <?php } ?>
        </tbody>
    </table>
</section>

<?php require __DIR__ . '/../../partials/footer.php'; ?>
