<?php $layout = 'back'; require __DIR__ . '/../../partials/header.php'; ?>

<section class="toolbar">
    <div>
        <h2><?php echo strpos($action, 'update') === 0 ? 'Modifier la recette' : 'Ajouter une recette'; ?></h2>
        <p class="muted">Contrôle de saisie côté client et côté serveur.</p>
    </div>
    <a class="btn btn-light" href="index.php?page=back_recettes">Retour</a>
</section>

<section class="form-card">
    <form method="POST" action="index.php?page=back_recette_<?php echo $action; ?>" data-form="recette">
        <label for="titre">Titre</label>
        <input id="titre" name="titre" type="text" value="<?php echo htmlspecialchars($recette['titre'] ?? ''); ?>">
        <div class="error-text"><?php echo $errors['titre'] ?? ''; ?></div>

        <label for="objectif">Objectif</label>
        <input id="objectif" name="objectif" type="text" value="<?php echo htmlspecialchars($recette['objectif'] ?? ''); ?>">
        <div class="error-text"><?php echo $errors['objectif'] ?? ''; ?></div>

        <label for="regime">Régime</label>
        <input id="regime" name="regime" type="text" value="<?php echo htmlspecialchars($recette['regime'] ?? ''); ?>">
        <div class="error-text"><?php echo $errors['regime'] ?? ''; ?></div>

        <label for="duree">Durée en minutes</label>
        <input id="duree" name="duree" type="text" value="<?php echo htmlspecialchars((string) ($recette['duree'] ?? '')); ?>">
        <div class="error-text"><?php echo $errors['duree'] ?? ''; ?></div>

        <button class="btn btn-primary" type="submit">Enregistrer</button>
    </form>
</section>

<?php require __DIR__ . '/../../partials/footer.php'; ?>
