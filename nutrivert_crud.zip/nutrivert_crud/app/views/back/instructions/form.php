<?php $layout = 'back'; require __DIR__ . '/../../partials/header.php'; ?>

<section class="toolbar">
    <div>
        <h2><?php echo strpos($action, 'update') === 0 ? 'Modifier l\'instruction' : 'Ajouter une instruction'; ?></h2>
        <p class="muted">Le champ ingrédients attend un JSON valide.</p>
    </div>
    <a class="btn btn-light" href="index.php?page=back_instructions">Retour</a>
</section>

<section class="form-card">
    <form method="POST" action="index.php?page=back_instruction_<?php echo $action; ?>" data-form="instruction">
        <label for="id_recette">Recette liée</label>
        <select id="id_recette" name="id_recette">
            <option value="">Choisir une recette</option>
            <?php foreach ($recettes as $recetteOption) { ?>
                <option value="<?php echo (int) $recetteOption['id_recette']; ?>" <?php echo (string) ($instruction['id_recette'] ?? '') === (string) $recetteOption['id_recette'] ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($recetteOption['titre']); ?>
                </option>
            <?php } ?>
        </select>
        <div class="error-text"><?php echo $errors['id_recette'] ?? ''; ?></div>

        <label for="etape">Étape</label>
        <input id="etape" name="etape" type="text" value="<?php echo htmlspecialchars($instruction['etape'] ?? ''); ?>">
        <div class="error-text"><?php echo $errors['etape'] ?? ''; ?></div>

        <label for="description">Description</label>
        <textarea id="description" name="description" rows="5"><?php echo htmlspecialchars($instruction['description'] ?? ''); ?></textarea>
        <div class="error-text"><?php echo $errors['description'] ?? ''; ?></div>

        <label for="ingredient_produit">Ingrédients / produits (JSON)</label>
        <textarea id="ingredient_produit" name="ingredient_produit" rows="8"><?php echo htmlspecialchars($instruction['ingredient_produit'] ?? ''); ?></textarea>
        <div class="error-text"><?php echo $errors['ingredient_produit'] ?? ''; ?></div>

        <button class="btn btn-primary" type="submit">Enregistrer</button>
    </form>
</section>

<?php require __DIR__ . '/../../partials/footer.php'; ?>
