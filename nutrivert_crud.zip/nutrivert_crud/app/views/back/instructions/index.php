<?php $layout = 'back'; require __DIR__ . '/../../partials/header.php'; ?>

<section class="toolbar">
    <div>
        <h2>CRUD Instructions</h2>
        <p class="muted">BackOffice de gestion des instructions.</p>
    </div>
    <a class="btn btn-primary" href="index.php?page=back_instruction_create">Ajouter une instruction</a>
</section>

<?php if (!empty($success)) { ?>
    <div class="alert success"><?php echo htmlspecialchars($success); ?></div>
<?php } ?>

<section class="table-card">
    <table class="data-table">
        <thead>
        <tr>
            <th>ID</th>
            <th>Recette</th>
            <th>Étape</th>
            <th>Description</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php if (empty($instructions)) { ?>
            <tr><td colspan="5">Aucune instruction trouvée.</td></tr>
        <?php } else { ?>
            <?php foreach ($instructions as $instruction) { ?>
                <tr>
                    <td><?php echo (int) $instruction['id_instruction']; ?></td>
                    <td><?php echo htmlspecialchars($instruction['recette_titre']); ?></td>
                    <td><?php echo htmlspecialchars($instruction['etape']); ?></td>
                    <td><?php echo htmlspecialchars($instruction['description']); ?></td>
                    <td class="actions-cell">
                        <a class="btn btn-small" href="index.php?page=back_instruction_edit&id=<?php echo (int) $instruction['id_instruction']; ?>">Modifier</a>
                        <form method="POST" action="index.php?page=back_instruction_delete&id=<?php echo (int) $instruction['id_instruction']; ?>" onsubmit="return confirmDelete();">
                            <button class="btn btn-danger btn-small" type="submit">Supprimer</button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        <?php } ?>
        </tbody>
    </table>
</section>

<?php require __DIR__ . '/../../partials/footer.php'; ?>
