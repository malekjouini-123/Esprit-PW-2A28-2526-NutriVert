<?php $layout = 'back'; require __DIR__ . '/../partials/header.php'; ?>

<section class="hero-card back-hero">
    <div>
        <span class="badge">BackOffice</span>
        <h2>Tableau de gestion</h2>
        <p>Gérez les entités <strong>recette</strong> et <strong>instruction</strong> avec un CRUD complet.</p>
    </div>
</section>

<section class="dashboard-grid">
    <a class="dashboard-box" href="index.php?page=back_recettes">
        <h3>Gestion des recettes</h3>
        <p>Ajouter, afficher, modifier et supprimer.</p>
    </a>
    <a class="dashboard-box" href="index.php?page=back_instructions">
        <h3>Gestion des instructions</h3>
        <p>Associer chaque étape à une recette.</p>
    </a>
    <a class="dashboard-box" href="index.php">
        <h3>Voir le FrontOffice</h3>
        <p>Consulter les recettes côté utilisateur.</p>
    </a>
</section>

<?php require __DIR__ . '/../partials/footer.php'; ?>
