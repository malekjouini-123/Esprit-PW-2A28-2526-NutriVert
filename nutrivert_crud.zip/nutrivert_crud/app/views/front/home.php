<?php $layout = 'front'; require __DIR__ . '/../partials/header.php'; ?>

<section class="hero-card">
    <div>
        <span class="badge">FrontOffice</span>
        <h2>Découvrez nos recettes durables</h2>
        <p>Consultez les recettes publiées et leurs instructions étape par étape.</p>
    </div>
    <a class="btn btn-primary" href="index.php?page=back_dashboard">Accéder au BackOffice</a>
</section>

<section class="grid-section">
    <?php if (empty($recettes)) { ?>
        <div class="empty-box">Aucune recette disponible.</div>
    <?php } else { ?>
        <?php foreach ($recettes as $recette) { ?>
            <article class="card recipe-card">
                <div class="card-top">
                    <span class="badge soft"><?php echo htmlspecialchars($recette['regime']); ?></span>
                    <span class="muted"><?php echo (int) $recette['duree']; ?> min</span>
                </div>
                <h3><?php echo htmlspecialchars($recette['titre']); ?></h3>
                <p><?php echo htmlspecialchars($recette['objectif']); ?></p>
                <a class="btn btn-secondary" href="index.php?page=front_recette&id=<?php echo (int) $recette['id_recette']; ?>">Voir le détail</a>
            </article>
        <?php } ?>
    <?php } ?>
</section>

<?php require __DIR__ . '/../partials/footer.php'; ?>
