<?php $layout = 'front'; require __DIR__ . '/../partials/header.php'; ?>

<section class="detail-card">
    <div class="card-top">
        <span class="badge"><?php echo htmlspecialchars($recette['regime']); ?></span>
        <span class="muted"><?php echo (int) $recette['duree']; ?> min</span>
    </div>
    <h2><?php echo htmlspecialchars($recette['titre']); ?></h2>
    <p class="lead"><?php echo htmlspecialchars($recette['objectif']); ?></p>
    <a class="btn btn-light" href="index.php">Retour aux recettes</a>
</section>

<section class="table-card">
    <h3>Instructions</h3>
    <?php if (empty($instructions)) { ?>
        <div class="empty-box">Aucune instruction liée à cette recette.</div>
    <?php } else { ?>
        <?php foreach ($instructions as $instruction) { ?>
            <article class="instruction-card">
                <h4><?php echo htmlspecialchars($instruction['etape']); ?></h4>
                <p><?php echo nl2br(htmlspecialchars($instruction['description'])); ?></p>
                <details>
                    <summary>Voir les ingrédients JSON</summary>
                    <pre><?php echo htmlspecialchars($instruction['ingredient_produit']); ?></pre>
                </details>
            </article>
        <?php } ?>
    <?php } ?>
</section>

<?php require __DIR__ . '/../partials/footer.php'; ?>
