<?php

class Recette
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function all(): array
    {
        $statement = $this->pdo->query('SELECT * FROM recette ORDER BY id_recette DESC');
        return $statement->fetchAll();
    }

    public function find(int $id): ?array
    {
        $statement = $this->pdo->prepare('SELECT * FROM recette WHERE id_recette = :id');
        $statement->execute(['id' => $id]);
        $recette = $statement->fetch();
        return $recette ?: null;
    }

    public function create(array $data): bool
    {
        $statement = $this->pdo->prepare(
            'INSERT INTO recette (titre, objectif, regime, duree) VALUES (:titre, :objectif, :regime, :duree)'
        );

        return $statement->execute([
            'titre' => $data['titre'],
            'objectif' => $data['objectif'],
            'regime' => $data['regime'],
            'duree' => $data['duree'],
        ]);
    }

    public function update(int $id, array $data): bool
    {
        $statement = $this->pdo->prepare(
            'UPDATE recette SET titre = :titre, objectif = :objectif, regime = :regime, duree = :duree WHERE id_recette = :id'
        );

        return $statement->execute([
            'id' => $id,
            'titre' => $data['titre'],
            'objectif' => $data['objectif'],
            'regime' => $data['regime'],
            'duree' => $data['duree'],
        ]);
    }

    public function delete(int $id): bool
    {
        $statement = $this->pdo->prepare('DELETE FROM recette WHERE id_recette = :id');
        return $statement->execute(['id' => $id]);
    }

    public function validate(array $data): array
    {
        $errors = [];

        if (!isset($data['titre']) || strlen(trim($data['titre'])) < 3) {
            $errors['titre'] = 'Le titre doit contenir au moins 3 caractères.';
        }

        if (!isset($data['objectif']) || strlen(trim($data['objectif'])) < 5) {
            $errors['objectif'] = 'L\'objectif doit contenir au moins 5 caractères.';
        }

        if (!isset($data['regime']) || trim($data['regime']) === '') {
            $errors['regime'] = 'Le régime est obligatoire.';
        }

        if (!isset($data['duree']) || !ctype_digit((string) trim($data['duree'])) || (int) $data['duree'] <= 0) {
            $errors['duree'] = 'La durée doit être un entier supérieur à 0.';
        }

        return $errors;
    }
}
