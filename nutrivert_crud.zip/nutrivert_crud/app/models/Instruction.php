<?php

class Instruction
{
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
    }

    public function all(): array
    {
        $sql = 'SELECT i.*, r.titre AS recette_titre
                FROM instruction i
                INNER JOIN recette r ON r.id_recette = i.id_recette
                ORDER BY i.id_instruction DESC';
        $statement = $this->pdo->query($sql);
        return $statement->fetchAll();
    }

    public function find(int $id): ?array
    {
        $statement = $this->pdo->prepare('SELECT * FROM instruction WHERE id_instruction = :id');
        $statement->execute(['id' => $id]);
        $instruction = $statement->fetch();
        return $instruction ?: null;
    }

    public function byRecette(int $recetteId): array
    {
        $statement = $this->pdo->prepare('SELECT * FROM instruction WHERE id_recette = :id ORDER BY id_instruction ASC');
        $statement->execute(['id' => $recetteId]);
        return $statement->fetchAll();
    }

    public function create(array $data): bool
    {
        $statement = $this->pdo->prepare(
            'INSERT INTO instruction (id_recette, etape, description, ingredient_produit)
             VALUES (:id_recette, :etape, :description, :ingredient_produit)'
        );

        return $statement->execute([
            'id_recette' => $data['id_recette'],
            'etape' => $data['etape'],
            'description' => $data['description'],
            'ingredient_produit' => $data['ingredient_produit'],
        ]);
    }

    public function update(int $id, array $data): bool
    {
        $statement = $this->pdo->prepare(
            'UPDATE instruction
             SET id_recette = :id_recette, etape = :etape, description = :description, ingredient_produit = :ingredient_produit
             WHERE id_instruction = :id'
        );

        return $statement->execute([
            'id' => $id,
            'id_recette' => $data['id_recette'],
            'etape' => $data['etape'],
            'description' => $data['description'],
            'ingredient_produit' => $data['ingredient_produit'],
        ]);
    }

    public function delete(int $id): bool
    {
        $statement = $this->pdo->prepare('DELETE FROM instruction WHERE id_instruction = :id');
        return $statement->execute(['id' => $id]);
    }

    public function validate(array $data): array
    {
        $errors = [];

        if (!isset($data['id_recette']) || !ctype_digit((string) trim($data['id_recette'])) || (int) $data['id_recette'] <= 0) {
            $errors['id_recette'] = 'Veuillez choisir une recette valide.';
        }

        if (!isset($data['etape']) || strlen(trim($data['etape'])) < 2) {
            $errors['etape'] = 'L\'étape doit contenir au moins 2 caractères.';
        }

        if (!isset($data['description']) || strlen(trim($data['description'])) < 5) {
            $errors['description'] = 'La description doit contenir au moins 5 caractères.';
        }

        if (!isset($data['ingredient_produit']) || trim($data['ingredient_produit']) === '') {
            $errors['ingredient_produit'] = 'Les ingrédients sont obligatoires.';
        } else {
            json_decode($data['ingredient_produit'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                $errors['ingredient_produit'] = 'Le champ ingrédients doit contenir un JSON valide.';
            }
        }

        return $errors;
    }
}
