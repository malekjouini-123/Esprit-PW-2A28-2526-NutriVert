<?php

class RecetteController extends BaseController
{
    private Recette $recetteModel;

    public function __construct(PDO $pdo)
    {
        $this->recetteModel = new Recette($pdo);
    }

    public function index(): void
    {
        $this->render('back/recettes/index', [
            'recettes' => $this->recetteModel->all(),
            'pageTitle' => 'BackOffice | Recettes',
            'success' => $_GET['success'] ?? '',
        ]);
    }

    public function create(): void
    {
        $this->render('back/recettes/form', [
            'pageTitle' => 'Ajouter une recette',
            'action' => 'store',
            'recette' => ['titre' => '', 'objectif' => '', 'regime' => '', 'duree' => ''],
            'errors' => [],
        ]);
    }

    public function store(): void
    {
        $data = [
            'titre' => trim($_POST['titre'] ?? ''),
            'objectif' => trim($_POST['objectif'] ?? ''),
            'regime' => trim($_POST['regime'] ?? ''),
            'duree' => trim($_POST['duree'] ?? ''),
        ];

        $errors = $this->recetteModel->validate($data);

        if (!empty($errors)) {
            $this->render('back/recettes/form', [
                'pageTitle' => 'Ajouter une recette',
                'action' => 'store',
                'recette' => $data,
                'errors' => $errors,
            ]);
            return;
        }

        $this->recetteModel->create($data);
        $this->redirect('index.php?page=back_recettes&success=Recette ajoutée avec succès');
    }

    public function edit(int $id): void
    {
        $recette = $this->recetteModel->find($id);

        if ($recette === null) {
            http_response_code(404);
            echo 'Recette introuvable.';
            return;
        }

        $this->render('back/recettes/form', [
            'pageTitle' => 'Modifier une recette',
            'action' => 'update&id=' . $id,
            'recette' => $recette,
            'errors' => [],
        ]);
    }

    public function update(int $id): void
    {
        $data = [
            'titre' => trim($_POST['titre'] ?? ''),
            'objectif' => trim($_POST['objectif'] ?? ''),
            'regime' => trim($_POST['regime'] ?? ''),
            'duree' => trim($_POST['duree'] ?? ''),
        ];

        $errors = $this->recetteModel->validate($data);

        if (!empty($errors)) {
            $data['id_recette'] = $id;
            $this->render('back/recettes/form', [
                'pageTitle' => 'Modifier une recette',
                'action' => 'update&id=' . $id,
                'recette' => $data,
                'errors' => $errors,
            ]);
            return;
        }

        $this->recetteModel->update($id, $data);
        $this->redirect('index.php?page=back_recettes&success=Recette modifiée avec succès');
    }

    public function delete(int $id): void
    {
        $this->recetteModel->delete($id);
        $this->redirect('index.php?page=back_recettes&success=Recette supprimée avec succès');
    }
}
