<?php

class InstructionController extends BaseController
{
    private Instruction $instructionModel;
    private Recette $recetteModel;

    public function __construct(PDO $pdo)
    {
        $this->instructionModel = new Instruction($pdo);
        $this->recetteModel = new Recette($pdo);
    }

    public function index(): void
    {
        $this->render('back/instructions/index', [
            'instructions' => $this->instructionModel->all(),
            'pageTitle' => 'BackOffice | Instructions',
            'success' => $_GET['success'] ?? '',
        ]);
    }

    public function create(): void
    {
        $this->render('back/instructions/form', [
            'pageTitle' => 'Ajouter une instruction',
            'action' => 'store',
            'instruction' => ['id_recette' => '', 'etape' => '', 'description' => '', 'ingredient_produit' => "[\n  {\"id_produit\": 1, \"nom_produit\": \"oeuf\", \"quantite\": \"2\"}\n]"],
            'recettes' => $this->recetteModel->all(),
            'errors' => [],
        ]);
    }

    public function store(): void
    {
        $data = [
            'id_recette' => trim($_POST['id_recette'] ?? ''),
            'etape' => trim($_POST['etape'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'ingredient_produit' => trim($_POST['ingredient_produit'] ?? ''),
        ];

        $errors = $this->instructionModel->validate($data);

        if (!empty($errors)) {
            $this->render('back/instructions/form', [
                'pageTitle' => 'Ajouter une instruction',
                'action' => 'store',
                'instruction' => $data,
                'recettes' => $this->recetteModel->all(),
                'errors' => $errors,
            ]);
            return;
        }

        $this->instructionModel->create($data);
        $this->redirect('index.php?page=back_instructions&success=Instruction ajoutée avec succès');
    }

    public function edit(int $id): void
    {
        $instruction = $this->instructionModel->find($id);

        if ($instruction === null) {
            http_response_code(404);
            echo 'Instruction introuvable.';
            return;
        }

        $this->render('back/instructions/form', [
            'pageTitle' => 'Modifier une instruction',
            'action' => 'update&id=' . $id,
            'instruction' => $instruction,
            'recettes' => $this->recetteModel->all(),
            'errors' => [],
        ]);
    }

    public function update(int $id): void
    {
        $data = [
            'id_recette' => trim($_POST['id_recette'] ?? ''),
            'etape' => trim($_POST['etape'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'ingredient_produit' => trim($_POST['ingredient_produit'] ?? ''),
        ];

        $errors = $this->instructionModel->validate($data);

        if (!empty($errors)) {
            $data['id_instruction'] = $id;
            $this->render('back/instructions/form', [
                'pageTitle' => 'Modifier une instruction',
                'action' => 'update&id=' . $id,
                'instruction' => $data,
                'recettes' => $this->recetteModel->all(),
                'errors' => $errors,
            ]);
            return;
        }

        $this->instructionModel->update($id, $data);
        $this->redirect('index.php?page=back_instructions&success=Instruction modifiée avec succès');
    }

    public function delete(int $id): void
    {
        $this->instructionModel->delete($id);
        $this->redirect('index.php?page=back_instructions&success=Instruction supprimée avec succès');
    }
}
