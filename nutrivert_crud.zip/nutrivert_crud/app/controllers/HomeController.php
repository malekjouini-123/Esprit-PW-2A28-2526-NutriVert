<?php

class HomeController extends BaseController
{
    private Recette $recetteModel;
    private Instruction $instructionModel;

    public function __construct(PDO $pdo)
    {
        $this->recetteModel = new Recette($pdo);
        $this->instructionModel = new Instruction($pdo);
    }

    public function index(): void
    {
        $recettes = $this->recetteModel->all();
        $this->render('front/home', [
            'recettes' => $recettes,
            'pageTitle' => 'NutriVert | FrontOffice',
        ]);
    }

    public function recetteDetail(int $id): void
    {
        $recette = $this->recetteModel->find($id);

        if ($recette === null) {
            http_response_code(404);
            echo 'Recette introuvable.';
            return;
        }

        $instructions = $this->instructionModel->byRecette($id);

        $this->render('front/recette_detail', [
            'recette' => $recette,
            'instructions' => $instructions,
            'pageTitle' => 'Détail Recette',
        ]);
    }
}
