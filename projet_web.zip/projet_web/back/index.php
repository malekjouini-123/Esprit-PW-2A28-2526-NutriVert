<?php
declare(strict_types=1);
header('Location: marketplace.php');
exit;
