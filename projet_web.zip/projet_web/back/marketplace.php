<?php
/**
 * Entrée backend — Administration marketplace (catégories & produits).
 * URL : http://localhost/projet_web/back/marketplace.php
 */
declare(strict_types=1);
require_once __DIR__ . '/Controller/AdminMarketplaceController.php';
(new AdminMarketplaceController())->dispatch();
