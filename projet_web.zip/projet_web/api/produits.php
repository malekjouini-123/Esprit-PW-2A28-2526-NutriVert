<?php
/**
 * Point d’entrée API produits — délègue au contrôleur MVC.
 */
declare(strict_types=1);
require_once dirname(__DIR__) . '/config.php';
nv_bootstrap();
require_once dirname(__DIR__) . '/Controller/ProduitController.php';
(new ProduitController())->handle();
