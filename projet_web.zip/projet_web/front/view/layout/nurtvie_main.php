<?php
declare(strict_types=1);
/**
 * Layout principal — couche View (MVC).
 *
 * @var string $title
 * @var string $css_href
 * @var string $js_saisie_href
 * @var string $js_page_href
 * @var string $logo_src
 * @var string $admin_href
 */
if (!function_exists('h')) {
    function h(?string $s): string
    {
        return htmlspecialchars((string) $s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title><?= h($title) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;14..32,400;14..32,500;14..32,600;14..32,700;14..32,800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="<?= h($css_href) ?>">
</head>
<body>

<?php include __DIR__ . '/../partials/nurtvie_header.php'; ?>
<?php include __DIR__ . '/../partials/nurtvie_accueil.php'; ?>
<?php include __DIR__ . '/../partials/nurtvie_services.php'; ?>
<?php include __DIR__ . '/../partials/nurtvie_recettes.php'; ?>
<?php include __DIR__ . '/../partials/nurtvie_marketplace.php'; ?>
<?php include __DIR__ . '/../partials/nurtvie_coaching.php'; ?>
<?php include __DIR__ . '/../partials/nurtvie_evenements.php'; ?>
<?php include __DIR__ . '/../partials/nurtvie_footer.php'; ?>

<script src="<?= h($js_saisie_href) ?>"></script>
<script src="<?= h($js_page_href) ?>"></script>
</body>
</html>
