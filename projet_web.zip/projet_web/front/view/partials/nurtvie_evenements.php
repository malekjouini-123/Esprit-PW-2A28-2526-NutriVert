<?php declare(strict_types=1); ?>
<section id="evenements">
    <h2 class="section-title"><i class="fas fa-calendar-check"></i> 📅 Événements & ateliers</h2>
    <div class="events-grid cards-grid">
        <div class="event-card glass-card">
            <i class="fas fa-leaf"></i>
            <h3>Atelier « Zéro gaspi maison »</h3>
            <p>📆 12 avril 2026 - 14h</p>
            <p>Apprenez à cuisiner les épluchures et restes alimentaires.</p>
            <span class="badge-event">Inscription gratuite</span>
            <button class="btn-card eventJoin">Je participe</button>
        </div>
        <div class="event-card glass-card">
            <i class="fas fa-chalkboard"></i>
            <h3>Conférence : IA & Nutrition durable</h3>
            <p>📆 25 avril 2026 - 18h30</p>
            <p>Comment la tech peut réduire l'empreinte alimentaire.</p>
            <button class="btn-card eventJoin">Réserver</button>
        </div>
        <div class="event-card glass-card">
            <i class="fas fa-hand-sparkles"></i>
            <h3>Marché éphémère local</h3>
            <p>📆 3 mai 2026 - 9h>13h</p>
            <p>Producteurs bio, ateliers dégustation.</p>
            <button class="btn-card eventJoin">S'inscrire</button>
        </div>
    </div>
</section>
