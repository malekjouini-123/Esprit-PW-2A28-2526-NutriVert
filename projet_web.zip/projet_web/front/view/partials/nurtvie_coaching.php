<?php declare(strict_types=1); ?>
<section id="coaching">
    <h2 class="section-title"><i class="fas fa-heartbeat"></i> 🧘 Coaching sur-mesure</h2>
    <div class="coaching-flex cards-grid">
        <div class="coach-card glass-card">
            <i class="fas fa-user-graduate"></i>
            <h3>Coach Ahmed</h3>
            <p>🏆 Perte de poids & rééquilibrage</p>
            <p>🌿 +200 transformations durables</p>
            <button class="btn-card selectCoach" data-coach="Ahmed">Choisir ce coach</button>
        </div>
        <div class="coach-card glass-card">
            <i class="fas fa-female"></i>
            <h3>Coach Sara</h3>
            <p>🥑 Nutrition sportive & vegan</p>
            <p>⚡ Coaching IA + humain</p>
            <button class="btn-card selectCoach" data-coach="Sara">Choisir ce coach</button>
        </div>
        <div class="coach-card glass-card">
            <i class="fas fa-globe"></i>
            <h3>Coach Lina</h3>
            <p>♻️ Zéro déchet & alimentation responsable</p>
            <p>🍃 Certifiée éco-nutrition</p>
            <button class="btn-card selectCoach" data-coach="Lina">Choisir ce coach</button>
        </div>
    </div>
</section>
