<?php
declare(strict_types=1);
/** @var string $logo_src @var string $admin_href */
?>
<header>
    <div class="logo-area">
        <img src="<?= h($logo_src) ?>" alt="NutriVert - Nutrition intelligente & écologique" class="logo-image" onerror="this.onerror=null; this.src='https://placehold.co/48x48?text=🌿';">
        <span class="logo-text">NutriVert</span>
    </div>
    <nav>
        <a href="#accueil">Accueil</a>
        <a href="#recettes-ai">Recettes AI</a>
        <a href="#marketplace">Marketplace</a>
        <a href="#coaching">Coaching</a>
        <a href="#evenements">Événements</a>
        <a href="<?= h($admin_href) ?>">Admin</a>
        <button class="btn-outline-light" id="signupBtn"><i class="fas fa-user-plus"></i> S'inscrire</button>
        <button class="btn-primary-green" id="loginBtn"><i class="fas fa-key"></i> Se connecter</button>
    </nav>
</header>
