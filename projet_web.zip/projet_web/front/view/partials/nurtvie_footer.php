<?php declare(strict_types=1); ?>
<footer>
    <p>🌱 © 2026 NutriVert — « Mangez intelligemment, vivez durablement » — Tech au service de la planète</p>
</footer>
