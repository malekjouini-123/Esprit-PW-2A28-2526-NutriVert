<?php declare(strict_types=1); ?>
<section id="services-overview">
    <h2 class="section-title"><i class="fas fa-star-of-life"></i> Nos services clés</h2>
    <div class="cards-grid">
        <div class="service-card glass-card">
            <i class="fas fa-robot"></i>
            <h3>Recettes AI</h3>
            <p>Générez des recettes zéro gaspi selon vos ingrédients. Anti-gaspillage intelligent.</p>
            <button class="btn-card" id="navRecettes">🍽️ Essayer</button>
        </div>
        <div class="service-card glass-card">
            <i class="fas fa-store"></i>
            <h3>Marketplace éco</h3>
            <p>Comparez l'empreinte carbone, prix local vs industriel. Achetez responsable.</p>
            <button class="btn-card" id="navMarket">🛒 Explorer</button>
        </div>
        <div class="service-card glass-card">
            <i class="fas fa-chalkboard-user"></i>
            <h3>Coaching durable</h3>
            <p>Coach certifiés : perte de poids, vegan, réduction déchets. Suivi personnalisé.</p>
            <button class="btn-card" id="navCoaching">🧑‍🏫 Réserver</button>
        </div>
        <div class="service-card glass-card">
            <i class="fas fa-calendar-alt"></i>
            <h3>Événements green</h3>
            <p>Ateliers zéro déchet, conférences nutrition & planète. Rejoignez le mouvement.</p>
            <button class="btn-card" id="navEvents">📅 Voir agenda</button>
        </div>
    </div>
</section>
