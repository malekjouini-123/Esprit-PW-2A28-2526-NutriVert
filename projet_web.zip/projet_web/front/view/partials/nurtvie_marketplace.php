<?php declare(strict_types=1); ?>
<section id="marketplace">
    <h2 class="section-title"><i class="fas fa-chart-simple"></i> 🌍 Marketplace éco-responsable</h2>
    <p class="mp-intro">Explorez les produits par <strong>catégorie</strong> (légumes, fruits, viandes…), puis repérez les <strong>labels</strong> (Bio, Local, Sans gluten). Gérez le catalogue ci-dessous — les données viennent de la base <strong>NutriVert</strong> (via l’API PHP).</p>

    <div class="marketplace-layout">
        <aside class="mp-sidebar glass-card">
            <h4><i class="fas fa-filter"></i> Catégories</h4>
            <p style="font-size:0.88rem;color:#3d5c35;margin:0;">Afficher les produits :</p>
            <div id="mpCategoryChips" class="mp-chips" aria-label="Filtre par catégorie"></div>

            <details class="mp-manage">
                <summary><i class="fas fa-sliders-h"></i> Gestion du catalogue</summary>
                <div class="mp-manage-inner">
                    <h4>Catégories</h4>
                    <ul id="mpCatList" class="mp-mini-list"></ul>
                    <form id="mpCatForm" class="mp-form" autocomplete="off" novalidate>
                        <input type="hidden" id="mpCatEditId" value="">
                        <label for="mpCatNom">Nom de la catégorie</label>
                        <input id="mpCatNom" type="text" placeholder="Ex. Légumes, Fruits, Viandes…" maxlength="120" required>
                        <span id="mpCatNom_err" class="mp-field-error" role="alert"></span>
                        <label for="mpCatDesc">Description (optionnel)</label>
                        <input id="mpCatDesc" type="text" placeholder="Courte description" maxlength="255">
                        <span id="mpCatDesc_err" class="mp-field-error" role="alert"></span>
                        <div class="mp-form-actions">
                            <button type="submit" class="btn-primary-green" id="mpCatSubmit">Enregistrer</button>
                            <button type="button" class="btn-outline-light" id="mpCatReset">Nouvelle</button>
                        </div>
                    </form>

                    <h4>Produit</h4>
                    <form id="mpProdForm" class="mp-form" autocomplete="off" novalidate>
                        <input type="hidden" id="mpProdEditId" value="">
                        <label for="mpProdCategorie">Catégorie (Légumes, Viandes…)</label>
                        <select id="mpProdCategorie" required></select>
                        <span id="mpProdCategorie_err" class="mp-field-error" role="alert"></span>
                        <label for="mpProdNom">Nom du produit</label>
                        <input id="mpProdNom" type="text" placeholder="Ex. Banane, Tomates…" maxlength="180" required>
                        <span id="mpProdNom_err" class="mp-field-error" role="alert"></span>
                        <label for="mpProdLabelSelect">Labels (comme la catégorie : choix dans la liste)</label>
                        <div class="mp-label-select-wrap">
                            <select id="mpProdLabelSelect" multiple size="6" aria-describedby="mpProdLabelHint">
                                <option value="Bio">Bio</option>
                                <option value="Local">Local</option>
                                <option value="Sans gluten">Sans gluten</option>
                                <option value="Équitable">Équitable</option>
                                <option value="Circuit court">Circuit court</option>
                                <option value="AOP">AOP</option>
                                <option value="Saison">Saison</option>
                            </select>
                            <p id="mpProdLabelHint" class="mp-label-hint">Astuce : maintenez <strong>Ctrl</strong> (Windows) ou <strong>Cmd</strong> (Mac) pour sélectionner plusieurs labels. Laisser vide si aucun.</p>
                        </div>
                        <span id="mpProdLabel_err" class="mp-field-error" role="alert"></span>
                        <label for="mpProdProducteur">Producteur / origine</label>
                        <input id="mpProdProducteur" type="text" placeholder="Ferme, coopérative…" maxlength="150">
                        <span id="mpProdProducteur_err" class="mp-field-error" role="alert"></span>
                        <div class="mp-form-row">
                            <div>
                                <label for="mpProdPrix">Prix (DT)</label>
                                <input id="mpProdPrix" type="number" step="0.01" min="0" value="0" required>
                                <span id="mpProdPrix_err" class="mp-field-error" role="alert"></span>
                            </div>
                            <div>
                                <label for="mpProdCo2">Empreinte CO₂ (kg)</label>
                                <input id="mpProdCo2" type="number" step="0.01" min="0" placeholder="optionnel">
                                <span id="mpProdCo2_err" class="mp-field-error" role="alert"></span>
                            </div>
                        </div>
                        <label for="mpProdIcone">Icône (Font Awesome)</label>
                        <select id="mpProdIcone">
                            <option value="fa-seedling">🌱 Graine</option>
                            <option value="fa-apple-alt">Fruit / légume</option>
                            <option value="fa-leaf">Feuille</option>
                            <option value="fa-carrot">Carotte</option>
                            <option value="fa-fish">Poisson</option>
                            <option value="fa-egg">Œufs</option>
                            <option value="fa-bread-slice">Boulangerie</option>
                            <option value="fa-truck">Livraison / industriel</option>
                        </select>
                        <div class="mp-form-actions">
                            <button type="submit" class="btn-primary-green" id="mpProdSubmit">Ajouter le produit</button>
                            <button type="button" class="btn-outline-light" id="mpProdReset">Réinitialiser</button>
                        </div>
                    </form>
                </div>
            </details>
        </aside>

        <div class="mp-main">
            <div id="mpApiMsg" class="mp-msg" style="display:none;" role="status"></div>
            <div class="cards-grid mp-grid" id="marketplaceGrid"></div>
            <div id="shoppingToast" style="margin-top: 1.2rem; font-weight: 500; background: #daf5ce; border-radius: 2rem; padding: 0.4rem 1rem; display: inline-block;"></div>
        </div>
    </div>
</section>
