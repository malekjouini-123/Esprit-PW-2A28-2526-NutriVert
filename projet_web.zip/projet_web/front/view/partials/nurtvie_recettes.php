<?php declare(strict_types=1); ?>
<section id="recettes-ai">
    <h2 class="section-title"><i class="fas fa-microchip"></i> 🤖 Générateur de recettes IA</h2>
    <div class="glass-card ai-recipe-box">
        <div class="recipe-generator">
            <input type="text" id="ingredientInput" placeholder="Ex: courgettes, riz, pois chiches, tomate..." value="courgettes, riz, tomate">
            <button id="generateRecipeBtn" class="btn-primary-green"><i class="fas fa-magic"></i> Générer une recette</button>
        </div>
        <div id="dynamicRecipeDisplay" style="margin-top: 0.8rem;">
            <div class="recette-card" style="background:rgba(250,255,240,0.8); border-radius:1.5rem; padding:1.2rem;">
                <h3>🌿 Riz aux courgettes parfumé</h3>
                <p>🔥 310 kcal | Protéines 9g | Zéro gaspi</p>
                <p><span class="badge-event">💡 Astuce : ajoutez fromage de chèvre local</span></p>
                <button class="btn-card missing-market-link" data-produit="fromage">Voir alternative bio</button>
            </div>
        </div>
    </div>
</section>
