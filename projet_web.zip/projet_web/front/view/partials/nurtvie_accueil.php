<?php declare(strict_types=1); ?>
<section id="accueil">
    <div class="hero">
        <h2>🌱 NutriVert</h2>
        <div class="slogan">« Mangez intelligemment, vivez durablement »</div>
        <p>L'écosystème qui réunit nutrition personnalisée, IA green, marketplace éthique et communauté engagée.</p>
        <button class="btn-primary-green" id="exploreBtn" style="padding:0.8rem 2rem; font-size:1rem;">✨ Découvrir nos services</button>
    </div>
</section>
