/**
 * Contrôle de saisie partagé — marketplace catégorie / produit
 * Utilisé par view/nurtvie.php (front) et back/view/marketplace_admin.php (admin).
 */
(function (global) {
    'use strict';

    function setFieldError(fieldId, errId, message) {
        const el = document.getElementById(fieldId);
        const span = document.getElementById(errId);
        if (message) {
            if (el) el.classList.add('field-invalid');
            if (span) span.textContent = message;
        } else {
            if (el) el.classList.remove('field-invalid');
            if (span) span.textContent = '';
        }
    }

    function clearErrorsCategory(cfg) {
        setFieldError(cfg.nomId, cfg.errNomId, '');
        setFieldError(cfg.descId, cfg.errDescId, '');
    }

    function clearErrorsProduct(cfg) {
        setFieldError(cfg.categorieId, cfg.errCategorieId, '');
        setFieldError(cfg.nomId, cfg.errNomId, '');
        if (cfg.labelSelectId && cfg.errLabelsId) {
            setFieldError(cfg.labelSelectId, cfg.errLabelsId, '');
        }
        if (cfg.labelsWrapId && cfg.errLabelsId) {
            const span = document.getElementById(cfg.errLabelsId);
            if (span) span.textContent = '';
            const wrap = document.getElementById(cfg.labelsWrapId);
            if (wrap) wrap.classList.remove('field-invalid');
        }
        setFieldError(cfg.producteurId, cfg.errProducteurId, '');
        setFieldError(cfg.prixId, cfg.errPrixId, '');
        setFieldError(cfg.co2Id, cfg.errCo2Id, '');
    }

    function validateCategory(cfg) {
        clearErrorsCategory(cfg);
        let ok = true;
        const nomEl = document.getElementById(cfg.nomId);
        const descEl = document.getElementById(cfg.descId);
        if (!nomEl || !descEl) return false;
        const nom = nomEl.value.trim();
        if (nom.length < 2) {
            setFieldError(cfg.nomId, cfg.errNomId, 'Indiquez au moins 2 caractères pour le nom.');
            ok = false;
        } else if (nom.length > 120) {
            setFieldError(cfg.nomId, cfg.errNomId, 'Maximum 120 caractères.');
            ok = false;
        }
        const desc = descEl.value.trim();
        if (desc.length > 255) {
            setFieldError(cfg.descId, cfg.errDescId, 'Maximum 255 caractères.');
            ok = false;
        }
        return ok;
    }

    function validateProduct(cfg) {
        clearErrorsProduct(cfg);
        let ok = true;
        const catSel = document.getElementById(cfg.categorieId);
        if (!catSel) return false;
        const cid = parseInt(catSel.value, 10);
        if (!catSel.options.length || !Number.isFinite(cid) || cid < 1) {
            setFieldError(cfg.categorieId, cfg.errCategorieId, 'Choisissez une catégorie dans la liste.');
            ok = false;
        }
        const nomEl = document.getElementById(cfg.nomId);
        if (!nomEl) return false;
        const nom = nomEl.value.trim();
        if (nom.length < 2) {
            setFieldError(cfg.nomId, cfg.errNomId, 'Le nom du produit doit faire au moins 2 caractères.');
            ok = false;
        } else if (nom.length > 180) {
            setFieldError(cfg.nomId, cfg.errNomId, 'Maximum 180 caractères.');
            ok = false;
        }
        const prodEl = document.getElementById(cfg.producteurId);
        if (prodEl) {
            const prod = prodEl.value.trim();
            if (prod.length > 150) {
                setFieldError(cfg.producteurId, cfg.errProducteurId, 'Maximum 150 caractères.');
                ok = false;
            }
        }
        const prixEl = document.getElementById(cfg.prixId);
        if (!prixEl) return false;
        const prix = parseFloat(prixEl.value);
        if (!Number.isFinite(prix) || prix < 0) {
            setFieldError(cfg.prixId, cfg.errPrixId, 'Indiquez un prix valide (nombre ≥ 0).');
            ok = false;
        } else if (prix > 999999.99) {
            setFieldError(cfg.prixId, cfg.errPrixId, 'Prix trop élevé.');
            ok = false;
        }
        const co2El = document.getElementById(cfg.co2Id);
        if (co2El) {
            const co2v = co2El.value.trim();
            if (co2v !== '') {
                const co2 = parseFloat(co2v);
                if (!Number.isFinite(co2) || co2 < 0) {
                    setFieldError(cfg.co2Id, cfg.errCo2Id, 'Empreinte CO₂ invalide (nombre ≥ 0).');
                    ok = false;
                }
            }
        }
        return ok;
    }

    function attachClearListenersCategory(formSelector, cfg) {
        const form = document.querySelector(formSelector);
        if (!form) return;
        form.addEventListener('input', function (e) {
            const t = e.target;
            if (!(t instanceof HTMLElement)) return;
            if (t.id === cfg.nomId) setFieldError(cfg.nomId, cfg.errNomId, '');
            if (t.id === cfg.descId) setFieldError(cfg.descId, cfg.errDescId, '');
        });
    }

    function attachClearListenersProduct(formSelector, cfg) {
        const form = document.querySelector(formSelector);
        if (!form) return;
        form.addEventListener('input', function (e) {
            const t = e.target;
            if (!(t instanceof HTMLElement)) return;
            const map = {};
            map[cfg.nomId] = cfg.errNomId;
            map[cfg.producteurId] = cfg.errProducteurId;
            map[cfg.prixId] = cfg.errPrixId;
            map[cfg.co2Id] = cfg.errCo2Id;
            if (map[t.id]) setFieldError(t.id, map[t.id], '');
        });
        const cat = document.getElementById(cfg.categorieId);
        if (cat) {
            cat.addEventListener('change', function () {
                setFieldError(cfg.categorieId, cfg.errCategorieId, '');
            });
        }
        if (cfg.labelSelectId && cfg.errLabelsId) {
            const lab = document.getElementById(cfg.labelSelectId);
            if (lab) {
                lab.addEventListener('change', function () {
                    setFieldError(cfg.labelSelectId, cfg.errLabelsId, '');
                });
            }
        }
        if (cfg.labelsWrapId) {
            const wrap = document.getElementById(cfg.labelsWrapId);
            if (wrap) {
                wrap.addEventListener('change', function () {
                    if (cfg.errLabelsId) {
                        const span = document.getElementById(cfg.errLabelsId);
                        if (span) span.textContent = '';
                    }
                    wrap.classList.remove('field-invalid');
                });
            }
        }
    }

    global.NV_SaisieMarketplace = {
        setFieldError: setFieldError,
        clearErrorsCategory: clearErrorsCategory,
        clearErrorsProduct: clearErrorsProduct,
        validateCategory: validateCategory,
        validateProduct: validateProduct,
        attachClearListenersCategory: attachClearListenersCategory,
        attachClearListenersProduct: attachClearListenersProduct
    };
})(typeof window !== 'undefined' ? window : this);
