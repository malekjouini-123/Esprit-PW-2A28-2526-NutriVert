(function() {
        // ---------- RECETTES IA dynamique ----------
        const recipesDB = [
            { name: "Courgettes farcies au riz & tomates", calories: "320 kcal", proteines: "11g", missing: "fromage de chèvre", link: "fromage", astuce: "fromage bio local" },
            { name: "Buddha bowl pois chiches & avocat", calories: "540 kcal", proteines: "19g", missing: "citron", link: "citron", astuce: "jus de citron bio" },
            { name: "Soupe verte éco-responsable", calories: "120 kcal", proteines: "4g", missing: "graines de courge", link: "graines", astuce: "graines locales" },
            { name: "Omelette aux légumes du marché", calories: "265 kcal", proteines: "17g", missing: "oignon nouveau", link: "oignon", astuce: "oignon bio" }
        ];

        const ingredientInput = document.getElementById('ingredientInput');
        const generateBtn = document.getElementById('generateRecipeBtn');
        const recipeDisplay = document.getElementById('dynamicRecipeDisplay');

        function getRecipeByInput(text) {
            const lower = text.toLowerCase();
            if (lower.includes("courgette") || lower.includes("riz")) return recipesDB[0];
            if (lower.includes("pois chiche") || lower.includes("avocat")) return recipesDB[1];
            return recipesDB[Math.floor(Math.random() * recipesDB.length)];
        }

        function renderRecipe(recipe) {
            recipeDisplay.innerHTML = `
                <div class="recette-card" style="background:rgba(255,255,245,0.9); border-radius:1.5rem; padding:1.2rem;">
                    <h3>🌱 ${recipe.name}</h3>
                    <p>🔥 ${recipe.calories} | Protéines ${recipe.proteines}</p>
                    <p><span class="badge-event">🥗 Ingrédient suggéré : ${recipe.missing}</span></p>
                    <button class="btn-card missing-market-link" data-produit="${recipe.link}">🔍 Voir alternative dans Marketplace</button>
                </div>
            `;
            const newBtn = recipeDisplay.querySelector('.missing-market-link');
            if(newBtn) {
                newBtn.addEventListener('click', () => {
                    document.getElementById('marketplace').scrollIntoView({ behavior: 'smooth' });
                    highlightMarketItem(newBtn.getAttribute('data-produit'));
                });
            }
        }

        generateBtn.addEventListener('click', () => {
            let val = ingredientInput.value.trim();
            if(!val) { ingredientInput.placeholder = "Ajoutez des ingrédients !"; return; }
            const recipe = getRecipeByInput(val);
            renderRecipe(recipe);
        });
        renderRecipe(recipesDB[0]);

        // API Marketplace — racine projet (index.php) ou dossier view/ (ancienne URL)
        const API_BASE = (function () {
            const path = window.location.pathname || '';
            if (path.includes('/view/')) {
                return new URL('../api/', window.location.href).href;
            }
            return new URL('api/', window.location.href).href;
        })();

        function highlightMarketItem(query) {
            const items = document.querySelectorAll('#marketplaceGrid .mp-prod-card');
            const q = (query || '').toLowerCase();
            items.forEach(card => {
                const title = card.querySelector('h3')?.innerText.toLowerCase() || '';
                if (title.includes(q) || (q === 'fromage' && title.includes('fromage'))) {
                    card.classList.add('highlight');
                    card.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    setTimeout(() => card.classList.remove('highlight'), 1000);
                }
            });
        }

        let shopping = [];
        const toastDiv = document.getElementById('shoppingToast');
        function updateToastList() {
            if (shopping.length === 0) toastDiv.innerHTML = '🛒 Votre liste éco est vide. Ajoutez des produits responsables !';
            else toastDiv.innerHTML = `🌱 Ma liste durable : ${shopping.join(', ')}  ✅`;
        }

        const mpMsg = document.getElementById('mpApiMsg');
        function showMpMsg(text, ok) {
            if (!text) {
                mpMsg.style.display = 'none';
                mpMsg.textContent = '';
                return;
            }
            mpMsg.style.display = 'block';
            mpMsg.className = 'mp-msg ' + (ok ? 'ok' : 'err');
            mpMsg.textContent = text;
        }

        /** Contrôle de saisie partagé (js/nv_saisie_marketplace.js) — même logique que l’admin */
        const NV = window.NV_SaisieMarketplace;
        const NV_CFG_CAT = {
            nomId: 'mpCatNom',
            descId: 'mpCatDesc',
            errNomId: 'mpCatNom_err',
            errDescId: 'mpCatDesc_err'
        };
        const NV_CFG_PROD = {
            categorieId: 'mpProdCategorie',
            nomId: 'mpProdNom',
            producteurId: 'mpProdProducteur',
            prixId: 'mpProdPrix',
            co2Id: 'mpProdCo2',
            errCategorieId: 'mpProdCategorie_err',
            errNomId: 'mpProdNom_err',
            errProducteurId: 'mpProdProducteur_err',
            errPrixId: 'mpProdPrix_err',
            errCo2Id: 'mpProdCo2_err',
            labelSelectId: 'mpProdLabelSelect',
            errLabelsId: 'mpProdLabel_err'
        };
        if (NV) {
            NV.attachClearListenersCategory('#mpCatForm', NV_CFG_CAT);
            NV.attachClearListenersProduct('#mpProdForm', NV_CFG_PROD);
        }

        function mpProdLabelsJoined() {
            const sel = document.getElementById('mpProdLabelSelect');
            return [...sel.selectedOptions].map(o => o.value).join(', ');
        }

        function mpProdLabelsApplyFromString(str) {
            const sel = document.getElementById('mpProdLabelSelect');
            [...sel.options].forEach(o => { o.selected = false; });
            if (!str || !String(str).trim()) return;
            String(str).split(',').map(s => s.trim()).filter(Boolean).forEach(p => {
                const opt = [...sel.options].find(o => o.value.toLowerCase() === p.toLowerCase());
                if (opt) opt.selected = true;
            });
        }

        async function mpFetchJson(url, opts) {
            const res = await fetch(url, opts);
            const data = await res.json().catch(() => ({}));
            if (!res.ok) throw new Error(data.error || data.detail || res.statusText || 'Erreur réseau');
            return data;
        }

        let mpCategories = [];
        let mpFilterCatId = 0;

        function renderCategoryChips() {
            const el = document.getElementById('mpCategoryChips');
            if (!el) return;
            el.innerHTML = '';
            const all = document.createElement('button');
            all.type = 'button';
            all.className = 'mp-chip' + (mpFilterCatId === 0 ? ' active' : '');
            all.textContent = 'Toutes';
            all.addEventListener('click', () => { mpFilterCatId = 0; syncChipActive(); loadProducts(); });
            el.appendChild(all);
            mpCategories.forEach(c => {
                const b = document.createElement('button');
                b.type = 'button';
                b.className = 'mp-chip' + (mpFilterCatId === c.id ? ' active' : '');
                b.textContent = c.nom;
                b.addEventListener('click', () => { mpFilterCatId = c.id; syncChipActive(); loadProducts(); });
                el.appendChild(b);
            });
        }

        function syncChipActive() {
            const chips = document.querySelectorAll('#mpCategoryChips .mp-chip');
            chips.forEach((chip, i) => {
                if (i === 0) chip.classList.toggle('active', mpFilterCatId === 0);
                else {
                    const id = mpCategories[i - 1]?.id;
                    chip.classList.toggle('active', id === mpFilterCatId);
                }
            });
        }

        function fillProdCategorySelect() {
            const sel = document.getElementById('mpProdCategorie');
            if (!sel) return;
            const cur = sel.value;
            sel.innerHTML = '';
            mpCategories.forEach(c => {
                const o = document.createElement('option');
                o.value = String(c.id);
                o.textContent = c.nom;
                sel.appendChild(o);
            });
            if (cur && [...sel.options].some(o => o.value === cur)) sel.value = cur;
        }

        function renderCatManageList() {
            const ul = document.getElementById('mpCatList');
            if (!ul) return;
            ul.innerHTML = '';
            if (mpCategories.length === 0) {
                ul.innerHTML = '<li><span>Aucune catégorie — ajoutez-en une.</span></li>';
                return;
            }
            mpCategories.forEach(c => {
                const li = document.createElement('li');
                li.innerHTML = `<span>${escapeHtml(c.nom)}</span><div class="mp-row-actions">
                    <button type="button" data-cat-edit="${c.id}">Modifier</button>
                    <button type="button" class="mp-danger" data-cat-del="${c.id}">Supprimer</button>
                </div>`;
                ul.appendChild(li);
            });
        }

        function escapeHtml(s) {
            const d = document.createElement('div');
            d.textContent = s == null ? '' : String(s);
            return d.innerHTML;
        }

        function escapeAttr(s) {
            return String(s == null ? '' : s)
                .replace(/&/g, '&amp;')
                .replace(/"/g, '&quot;')
                .replace(/</g, '&lt;');
        }

        function renderProductsList(rows) {
            const grid = document.getElementById('marketplaceGrid');
            if (!grid) return;
            grid.innerHTML = '';
            if (!rows.length) {
                grid.innerHTML = '<div class="mp-empty">Aucun produit pour ce filtre. Ajoutez-en via « Gestion du catalogue » ou importez <code>base_de_donnee/nutrivert.sql</code> dans phpMyAdmin.</div>';
                return;
            }
            rows.forEach(p => {
                const card = document.createElement('div');
                card.className = 'service-card glass-card mp-prod-card';
                let iconClass = (p.icone || 'fa-seedling').trim();
                if (!iconClass.startsWith('fa-')) iconClass = 'fa-' + iconClass;
                const labelHtml = p.label ? `<div class="mp-label-line"><i class="fas fa-tag"></i> ${escapeHtml(p.label)}</div>` : '';
                const co2 = p.empreinte_co2 != null && p.empreinte_co2 !== '' ? `<div>✅ Empreinte : <strong>${escapeHtml(String(p.empreinte_co2))}</strong> kg CO₂</div>` : '<div>🌿 Empreinte : <em>non renseignée</em></div>';
                const nomAttr = escapeAttr(p.nom);
                const labelAttr = escapeAttr(p.label || '');
                const prodAttr = escapeAttr(p.producteur || '');
                card.innerHTML = `
                    <div class="mp-cat-pill">${escapeHtml(p.categorie_nom || '')}</div>
                    <i class="fas ${iconClass}"></i>
                    <h3>${escapeHtml(p.nom)}</h3>
                    ${labelHtml}
                    <div class="mp-prod-meta">
                        <div>🌱 <strong>${escapeHtml(p.producteur || '—')}</strong> — <strong>${Number(p.prix).toFixed(2)}</strong> DT</div>
                        ${co2}
                    </div>
                    <div class="mp-prod-actions">
                        <button type="button" class="btn-card addToList" data-produit="${nomAttr}">➕ Liste éco</button>
                        <button type="button" class="btn-card mp-edit-prod" data-id="${p.id}" data-categorie-id="${p.categorie_id}" data-nom="${nomAttr}" data-label="${labelAttr}" data-producteur="${prodAttr}" data-prix="${escapeAttr(String(p.prix))}" data-co2="${p.empreinte_co2 != null && p.empreinte_co2 !== '' ? escapeAttr(String(p.empreinte_co2)) : ''}" data-icone="${escapeAttr(iconClass)}">✏️ Modifier</button>
                        <button type="button" class="btn-card mp-del-prod" data-id="${p.id}" style="background:#a94442cc;">🗑 Supprimer</button>
                    </div>`;
                grid.appendChild(card);
            });
        }

        async function loadCategories() {
            try {
                mpCategories = await mpFetchJson(API_BASE + 'categories.php');
                renderCategoryChips();
                fillProdCategorySelect();
                renderCatManageList();
                showMpMsg('', true);
            } catch (e) {
                showMpMsg('Connexion API impossible : démarrez Apache/MySQL, importez la base NutriVert, puis ouvrez http://localhost/.../projet_web/index.php — ' + e.message, false);
            }
        }

        async function loadProducts() {
            const grid = document.getElementById('marketplaceGrid');
            if (!grid) return;
            try {
                const url = mpFilterCatId ? API_BASE + 'produits.php?categorie_id=' + encodeURIComponent(mpFilterCatId) : API_BASE + 'produits.php';
                const rows = await mpFetchJson(url);
                renderProductsList(rows);
            } catch (e) {
                grid.innerHTML = '<div class="mp-empty">' + escapeHtml(e.message) + '</div>';
            }
        }

        document.getElementById('marketplaceGrid')?.addEventListener('click', (e) => {
            const t = e.target;
            if (!(t instanceof HTMLElement)) return;
            const addBtn = t.closest('.addToList');
            if (addBtn) {
                const prod = addBtn.getAttribute('data-produit') || '';
                if (!shopping.includes(prod)) {
                    shopping.push(prod);
                    updateToastList();
                    addBtn.innerText = '✓ Ajouté';
                    setTimeout(() => { addBtn.innerText = '➕ Liste éco'; }, 1200);
                } else {
                    toastDiv.innerHTML = `⚠️ ${prod} déjà présent`;
                    setTimeout(() => updateToastList(), 1500);
                }
                return;
            }
            const editBtn = t.closest('.mp-edit-prod');
            if (editBtn) {
                const id = parseInt(editBtn.getAttribute('data-id') || '0', 10);
                document.getElementById('mpProdEditId').value = String(id);
                const cid = editBtn.getAttribute('data-categorie-id');
                if (cid) document.getElementById('mpProdCategorie').value = cid;
                document.getElementById('mpProdNom').value = editBtn.getAttribute('data-nom') || '';
                mpProdLabelsApplyFromString(editBtn.getAttribute('data-label') || '');
                document.getElementById('mpProdProducteur').value = editBtn.getAttribute('data-producteur') || '';
                document.getElementById('mpProdPrix').value = editBtn.getAttribute('data-prix') || '0';
                document.getElementById('mpProdCo2').value = editBtn.getAttribute('data-co2') || '';
                const ic = editBtn.getAttribute('data-icone') || 'fa-seedling';
                const selI = document.getElementById('mpProdIcone');
                if (selI) {
                    selI.value = [...selI.options].some(o => o.value === ic) ? ic : 'fa-seedling';
                }
                document.getElementById('mpProdSubmit').textContent = 'Enregistrer les modifications';
                document.getElementById('marketplace').scrollIntoView({ behavior: 'smooth', block: 'start' });
                document.querySelector('details.mp-manage')?.setAttribute('open', '');
                return;
            }
            const delBtn = t.closest('.mp-del-prod');
            if (delBtn) {
                const id = delBtn.getAttribute('data-id');
                if (!id || !confirm('Supprimer ce produit ?')) return;
                mpFetchJson(API_BASE + 'produits.php?id=' + encodeURIComponent(id), { method: 'DELETE' })
                    .then(() => { showMpMsg('Produit supprimé.', true); loadProducts(); })
                    .catch(err => showMpMsg(err.message, false));
            }
        });

        document.getElementById('mpCatForm')?.addEventListener('submit', async (ev) => {
            ev.preventDefault();
            if (!NV || !NV.validateCategory(NV_CFG_CAT)) {
                showMpMsg('Veuillez corriger les erreurs du formulaire catégorie.', false);
                document.querySelector('details.mp-manage')?.setAttribute('open', '');
                return;
            }
            const editId = document.getElementById('mpCatEditId').value;
            const body = { nom: document.getElementById('mpCatNom').value.trim(), description: document.getElementById('mpCatDesc').value.trim() };
            try {
                if (editId) {
                    await mpFetchJson(API_BASE + 'categories.php?id=' + encodeURIComponent(editId), { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
                    showMpMsg('Catégorie mise à jour.', true);
                } else {
                    await mpFetchJson(API_BASE + 'categories.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
                    showMpMsg('Catégorie ajoutée.', true);
                }
                document.getElementById('mpCatEditId').value = '';
                document.getElementById('mpCatNom').value = '';
                document.getElementById('mpCatDesc').value = '';
                document.getElementById('mpCatSubmit').textContent = 'Enregistrer';
                if (NV) NV.clearErrorsCategory(NV_CFG_CAT);
                await loadCategories();
                await loadProducts();
            } catch (e) {
                showMpMsg(e.message, false);
            }
        });

        document.getElementById('mpCatReset')?.addEventListener('click', () => {
            document.getElementById('mpCatEditId').value = '';
            document.getElementById('mpCatNom').value = '';
            document.getElementById('mpCatDesc').value = '';
            document.getElementById('mpCatSubmit').textContent = 'Enregistrer';
            if (NV) NV.clearErrorsCategory(NV_CFG_CAT);
        });

        document.getElementById('mpCatList')?.addEventListener('click', (e) => {
            const t = e.target;
            if (!(t instanceof HTMLElement)) return;
            const editId = t.getAttribute('data-cat-edit');
            const delId = t.getAttribute('data-cat-del');
            if (editId) {
                const c = mpCategories.find(x => String(x.id) === editId);
                if (!c) return;
                document.getElementById('mpCatEditId').value = editId;
                document.getElementById('mpCatNom').value = c.nom;
                document.getElementById('mpCatDesc').value = c.description || '';
                document.getElementById('mpCatSubmit').textContent = 'Mettre à jour';
                document.querySelector('details.mp-manage')?.setAttribute('open', '');
                return;
            }
            if (delId) {
                if (!confirm('Supprimer cette catégorie ? (impossible si des produits y sont liés)')) return;
                mpFetchJson(API_BASE + 'categories.php?id=' + encodeURIComponent(delId), { method: 'DELETE' })
                    .then(async () => { showMpMsg('Catégorie supprimée.', true); mpFilterCatId = 0; await loadCategories(); await loadProducts(); })
                    .catch(err => showMpMsg(err.message, false));
            }
        });

        document.getElementById('mpProdForm')?.addEventListener('submit', async (ev) => {
            ev.preventDefault();
            if (!NV || !NV.validateProduct(NV_CFG_PROD)) {
                showMpMsg('Veuillez corriger les erreurs du formulaire produit.', false);
                document.querySelector('details.mp-manage')?.setAttribute('open', '');
                return;
            }
            const editId = document.getElementById('mpProdEditId').value;
            const co2v = document.getElementById('mpProdCo2').value.trim();
            const labelStr = mpProdLabelsJoined().trim();
            const body = {
                categorie_id: parseInt(document.getElementById('mpProdCategorie').value, 10),
                nom: document.getElementById('mpProdNom').value.trim(),
                label: labelStr,
                producteur: document.getElementById('mpProdProducteur').value.trim(),
                prix: parseFloat(document.getElementById('mpProdPrix').value) || 0,
                empreinte_co2: co2v === '' ? null : parseFloat(co2v),
                icone: document.getElementById('mpProdIcone').value
            };
            try {
                if (editId) {
                    await mpFetchJson(API_BASE + 'produits.php?id=' + encodeURIComponent(editId), { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
                    showMpMsg('Produit mis à jour.', true);
                } else {
                    await mpFetchJson(API_BASE + 'produits.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
                    showMpMsg('Produit ajouté.', true);
                }
                document.getElementById('mpProdEditId').value = '';
                document.getElementById('mpProdSubmit').textContent = 'Ajouter le produit';
                document.getElementById('mpProdForm').reset();
                document.getElementById('mpProdPrix').value = '0';
                mpProdLabelsApplyFromString('');
                if (NV) NV.clearErrorsProduct(NV_CFG_PROD);
                fillProdCategorySelect();
                await loadProducts();
            } catch (e) {
                showMpMsg(e.message, false);
            }
        });

        document.getElementById('mpProdReset')?.addEventListener('click', () => {
            document.getElementById('mpProdEditId').value = '';
            document.getElementById('mpProdSubmit').textContent = 'Ajouter le produit';
            document.getElementById('mpProdForm').reset();
            document.getElementById('mpProdPrix').value = '0';
            mpProdLabelsApplyFromString('');
            if (NV) NV.clearErrorsProduct(NV_CFG_PROD);
            fillProdCategorySelect();
        });

        updateToastList();
        loadCategories().then(() => loadProducts());

        // coaching selection
        document.querySelectorAll('.selectCoach').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const coach = btn.getAttribute('data-coach');
                alert(`✨ Félicitations ! Vous avez choisi ${coach} comme coach. Un email de bienvenue vous sera envoyé pour démarrer votre programme durable.`);
            });
        });

        // Evenements participation
        document.querySelectorAll('.eventJoin').forEach(btn => {
            btn.addEventListener('click', () => {
                alert("🎉 Merci ! Vous êtes inscrit à cet événement. Un rappel sera envoyé. Ensemble pour une alimentation intelligente !");
            });
        });

        // Navigation buttons
        document.getElementById('navRecettes')?.addEventListener('click', () => document.getElementById('recettes-ai').scrollIntoView({ behavior: 'smooth' }));
        document.getElementById('navMarket')?.addEventListener('click', () => document.getElementById('marketplace').scrollIntoView({ behavior: 'smooth' }));
        document.getElementById('navCoaching')?.addEventListener('click', () => document.getElementById('coaching').scrollIntoView({ behavior: 'smooth' }));
        document.getElementById('navEvents')?.addEventListener('click', () => document.getElementById('evenements').scrollIntoView({ behavior: 'smooth' }));
        document.getElementById('exploreBtn')?.addEventListener('click', () => document.getElementById('services-overview').scrollIntoView({ behavior: 'smooth' }));
        
        // Login / Signup
        document.getElementById('loginBtn')?.addEventListener('click', () => alert("🔐 Connexion à votre espace NutriVert — Découvrez votre tableau de bord personnalisé."));
        document.getElementById('signupBtn')?.addEventListener('click', () => alert("🌿 Créez votre compte NutriVert et rejoignez la communauté green ! Rejoignez le mouvement 'Mangez intelligemment, vivez durablement'."));

        // Gestion d'erreur si l'image n'existe pas (fallback)
        const logoImg = document.querySelector('.logo-image');
        if(logoImg) {
            logoImg.addEventListener('error', function() {
                this.onerror = null;
                this.src = 'https://placehold.co/48x48?text=🌿';
                this.style.borderRadius = '50%';
            });
        }
    })();